# online-food-ordering-system-in-php
Note: Before proceding futher kindly extract admin.zip in the same folder.
watch this:https://imgur.com/a/L4VAytF

1.copy whole code in xampp/htdocs folder          
2.run xampp        
3.start mysql       
4.import sql database SQL/online_rest.sql       
5.run localhost/index.php on chrome         
